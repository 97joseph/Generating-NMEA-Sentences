# GPS-software-tests
Boost unit tests implemented for a chosen function(totalLength) in ready made code
Open the Analysis-Tests.pro in Qt
the test file is located in tests/analysis/totalLength.cpp
the function for that is being tested is in src/analysis/analysis-route.cpp
