#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE AllTests
#include <boost/test/unit_test.hpp>

/* This file generates the main() function for the Boost UTF test program.
 * The test suites themselves can be found in the other files in the 'tests/' directory.
 */
